package com.jsp.springjpa.repository;

import com.jsp.springjpa.*;
import com.jsp.springjpa.model.Task;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TaskRepository extends JpaRepository<Task,Long>
{
	
}
